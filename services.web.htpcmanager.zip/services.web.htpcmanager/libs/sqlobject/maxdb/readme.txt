This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

Author: <ahmedmo@wanadoo.fr>
Edigram SA - Paris France
Tel:0144779400

SAPDBAPI installation 
---------------------
The sapdb module can be downloaded from:

Win32
-------

ftp://ftp.sap.com/pub/sapdb/bin/win/sapdb-python-win32-7.4.03.31a.zip 


Linux 
------

ftp://ftp.sap.com/pub/sapdb/bin/linux/sapdb-python-linux-i386-7.4.03.31a.tgz 


uncompress the archive and add the sapdb directory path to your PYTHONPATH.




