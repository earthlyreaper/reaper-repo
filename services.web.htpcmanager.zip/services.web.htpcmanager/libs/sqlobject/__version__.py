
version = '1.3.1'
major   = 1
minor   = 3
micro   = 1
release_level = 'final'
serial  = 0
version_info = (major, minor, micro, release_level, serial)
