HTPC Manager
=====

A python based web application to manage the software on your Htpc. Htpc Manager combines all your favorite software into one slick interface.


## See full installation instructions at [htpc.io](http://htpc.io/)

Start with ```python Htpc.py```
